this folder includes some example training data produced as described in the associated paper.
In each case, column one is time, column 2 is raw current, column 3 is ground truth, i.e., the number of simulated ion channels open at one time.
